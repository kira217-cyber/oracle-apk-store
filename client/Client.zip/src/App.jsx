function App() {
  return (
    <>
      <div>New Project with Tailwind CSS</div>
    </>
  );
}

export default App;

import React from "react";

const IsoApp = () => {
  return (
    <div>
      <h1 className="text-2xl text-orange-600 text-center min-h-screen">
        No Include Api!
      </h1>
    </div>
  );
};

export default IsoApp;

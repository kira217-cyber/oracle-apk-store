import React from "react";

const Download = () => {
  return (
    <div>
      <h1 className="text-2xl text-indigo-600 text-center min-h-screen">
        No Include Api!
      </h1>
    </div>
  );
};

export default Download;

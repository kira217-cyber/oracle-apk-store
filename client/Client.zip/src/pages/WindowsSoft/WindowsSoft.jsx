import React from "react";

const WindowsSoft = () => {
  return (
    <div>
      <h1 className="text-2xl text-red-600 text-center min-h-screen">
        No Include Api!
      </h1>
    </div>
  );
};

export default WindowsSoft;
